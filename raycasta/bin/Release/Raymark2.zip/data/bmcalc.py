import statistics as s

file = open("ft.txt", "r")
lines = file.readlines()

data = [float(1000/(float(lines[i]))) for i in range(0,len(lines))]
stdev = s.stdev(data)
mean = s.mean(data)
print("FPS: " + str(round(mean, 2)) + " (stdev: " + str(round(stdev, 2)) + ")\n")
